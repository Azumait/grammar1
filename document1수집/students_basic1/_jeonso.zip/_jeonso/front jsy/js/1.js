// 주석
/* 주석 */

// 코딩 : 컴퓨터와 대화 (형용사 + 명사 X // 동사 O)

// 파라미터가 없는 메소드
function sayHello() {
    let name = prompt('당신의 이름은?')
    alert('Hello! '+ name)
}

// 파라미터가 있는 메소드
function sayHello2(potato) {
    alert('Hello! '+potato)
}